package com.hack.syncit.service

import com.hack.syncit.util.RestClientUtils
import com.hack.syncit.web.JiraStatus
import net.rcarz.jiraclient.BasicCredentials
import net.rcarz.jiraclient.Issue
import net.rcarz.jiraclient.JiraClient
import net.rcarz.jiraclient.JiraException
import org.apache.commons.httpclient.HttpStatus
import org.apache.commons.lang3.StringUtils
import org.apache.tomcat.util.http.fileupload.IOUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import wslite.rest.ContentType

import java.nio.charset.StandardCharsets

/**
 * Created by jyoti on 6/18/17.
 */
@Service
class JiraService {

    private static final Logger LOG = LoggerFactory.getLogger(JiraService.class);
    private static def AUTH_USER = "jira_admin"
    private static def AUTH_PWD = "no12blame"
    private static def SUCCESS = "SUCCESS"
    private static def FAILURE = "FAILURE"
    private static def JIRA_URL = "https://syncitjira.atlassian.net"
    private static def ISSUR_KEY_FORMAT="((?<!([A-Za-z]{1,10})-?)[A-Z]+-\\d+)"


    public def retriveIssue(key) {
        def formattedKey=retrieveJiraIssueFormatted(key)
        BasicCredentials creds = new BasicCredentials(AUTH_USER, AUTH_PWD)
        JiraClient jira = new JiraClient(JIRA_URL, creds)
        jira.getIssue(formattedKey)
    }

    public def updateStatus(key,status) {
        def formattedKey=retrieveJiraIssueFormatted(key)
        BasicCredentials creds = new BasicCredentials(AUTH_USER, AUTH_PWD)
        JiraClient jira = new JiraClient(JIRA_URL, creds)
        def returned=new JiraStatus()
        returned.key=formattedKey
        try{
            jira.getIssue(formattedKey).transition().execute(status)
            returned.status=SUCCESS

        }catch (JiraException e){
            returned.status="$FAILURE :$e"
            LOG.error('Error in changing status of issue {} issue:',formattedKey,e)
        }
        return returned
    }

    public def downloadIssue(key){
        def formattedKey=retrieveJiraIssueFormatted(key)
        def byte [] returned="No attachments found for Issue: "+formattedKey.getBytes()
        BasicCredentials creds = new BasicCredentials(AUTH_USER,AUTH_PWD)
        JiraClient jiraClient = new JiraClient(JIRA_URL, creds)
        Issue issue = jiraClient.getIssue(formattedKey)
        LOG.info('Here are the attachment links {}',issue.attachments)
        if(issue.attachments){
            ByteArrayOutputStream baos;
            URL toDownload = new URL(issue.getAttachments().last().toString());
            try {
                URLConnection conn = toDownload.openConnection();
                byte[] message = (AUTH_USER+":"+AUTH_PWD).getBytes("UTF-8");
                String encoded = javax.xml.bind.DatatypeConverter.printBase64Binary(message);
//            String encoded = Base64.getEncoder().encodeToString((AUTH_USER+":"+AUTH_PWD).getBytes(StandardCharsets.UTF_8));  //Java 8
                conn.setRequestProperty("Authorization", "Basic "+encoded);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.headerFields
                conn.connect();

                baos = new ByteArrayOutputStream();
                IOUtils.copy(conn.getInputStream(), baos);

                returned = baos.toByteArray();
            }
            catch (IOException e) {
                LOG.error('Error in retrieving issue attachment {} issue:',formattedKey,e)
            }finally{
                if(baos) baos.close()
            }

        }
        return returned

    }

    private def retrieveJiraIssueFormatted(key){
        def returned=key
        def matcher = (key =~ ISSUR_KEY_FORMAT)
        if(!matcher.matches()){
            LOG.info('pattern of jira key {} is not standard, will format now..',key)
            //first extract number portion
            def nbr=key.findAll(/\d+/ )*.toInteger()[0]
            def splitted=key.split("$nbr")
            if(splitted){
                if (splitted.size()==1){
                    def str=splitted.first()
                    returned="$str-$nbr"
                }
            }

        }
        return returned
    }


    public def updateStatusDeprecated( key,status) {
        RestClientUtils restUtils = new RestClientUtils()
        restUtils.basicAuthUser = AUTH_USER
        restUtils.basicAuthPassword = AUTH_PWD
        def restApi = "/rest/api/2/issue/"
        def url = "$JIRA_URL$restApi$key/transitions"

        def body={
            type ContentType.JSON
            json(
                    [transition: [id: retrieveStatusNumberFromString(status)] ]
            )
        }

        JiraStatus status1 = new JiraStatus()
        status1.key=key

        def jiraIssue = restUtils.post(url,body)
        if (jiraIssue.statusCode == HttpStatus.SC_NO_CONTENT) {
            status1.status = "SUCCESS"
        } else {
            LOG.error("Unable to get OK status code from jira using this rest url: $url : Status code is :$jiraIssue.statusCode  ")
            status1.status =  "FAILED - Status Code :$jiraIssue.statusCode"
        }
        return status1
    }

    public def retriveIssueDeprecated(issue) {
        RestClientUtils restUtils = new RestClientUtils()
        restUtils.basicAuthUser = AUTH_USER
        restUtils.basicAuthPassword = AUTH_PWD
        def restApi = "/rest/api/2/issue/"
        def url = "$JIRA_URL$restApi$issue"
        def jiraIssue = restUtils.get(url)
        def jiraIssueJson="Unable to retrieve issue"
        if (jiraIssue.statusCode == HttpStatus.SC_OK) {
            jiraIssueJson = jiraIssue.json
        }
        return jiraIssueJson.toString()

    }

    def retrieveStatusNumberFromString(status){
        def retStatus=11;
        if(StringUtils.equalsIgnoreCase("In Progress",status)){
            retStatus=21
        }
        if(StringUtils.equalsIgnoreCase("Done",status)){
            retStatus=31
        }
        if(StringUtils.equalsIgnoreCase("To Do",status)){
            retStatus=11
        }
        return retStatus
    }
}
