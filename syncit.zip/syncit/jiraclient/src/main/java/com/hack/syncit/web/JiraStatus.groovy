package com.hack.syncit.web;

class JiraStatus {
    def key
    def status

//    public JiraStatus(key,status){
//        this.key=key
//        this.status=status
//    }

}
