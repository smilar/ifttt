package com.hack.syncit.util

import org.apache.commons.httpclient.HttpStatus
import wslite.http.HTTPResponse
import wslite.http.auth.HTTPBasicAuthorization
import wslite.rest.RESTClient
import wslite.rest.RESTClientException
import wslite.rest.Response

/**
 * Created by D441139 on 10/22/2015.
 */
class RestClientUtils {
    def basicAuthUser
    def basicAuthPassword

    def post(String url,Closure content) {
        post(url,[:], content)
    }

    def post(String url,Map params=[:], Closure content=null) {
        def client = new RESTClient()
        if(basicAuthUser&&basicAuthPassword){
            client.authorization = new HTTPBasicAuthorization(basicAuthUser,basicAuthPassword)
        }
        url?client.setUrl(url):client
        try{
            client.post(params, content)
        }catch(RESTClientException e){
            e.response
        }
    }

    def put(String url,Closure content) {
        put(url,[:], content)
    }

    def put(String url,Map params=[:], Closure content=null) {
        def client = new RESTClient()
        if(basicAuthUser&&basicAuthPassword){
            client.authorization = new HTTPBasicAuthorization(basicAuthUser,basicAuthPassword)
        }
        url?client.setUrl(url):client
        try{
            client.put(params, content)
        }catch(RESTClientException e){
            e.response
        }
    }


    def delete(String url,Map params=[:], Closure content=null) {
        def client = new RESTClient()
        if(basicAuthUser&&basicAuthPassword){
            client.authorization = new HTTPBasicAuthorization(basicAuthUser,basicAuthPassword)
        }
        url?client.setUrl(url):client
        try{
            client.delete(params, content)
        }catch(RESTClientException e){
            e.response
        }
    }

    def get(String url, Map params=[:], Closure content=null){
        def client = new RESTClient()
        if(basicAuthUser&&basicAuthPassword){
            client.authorization = new HTTPBasicAuthorization(basicAuthUser,basicAuthPassword)
        }
        url?client.setUrl(url):client
        try{
            client.get(params, content)
        }catch(RESTClientException e){
            //Hack...not ideal but wanted to make sure we get a return code
            if(e.response){
                e.response
            }else{
                //if e.response is null, we want to create a response!
                Response resp = new Response( e.request,new HTTPResponse())
                resp.statusCode= HttpStatus.SC_BAD_GATEWAY
                resp
            }
        }
    }

}
