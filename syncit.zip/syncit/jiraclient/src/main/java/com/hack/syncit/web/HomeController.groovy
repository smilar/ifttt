package com.hack.syncit.web

import com.hack.syncit.service.JiraService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.io.InputStreamResource
import org.springframework.core.io.Resource
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.RequestBody;

import java.util.concurrent.atomic.AtomicLong

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/jiraservice")
public class HomeController {

    @Autowired
    JiraService jiraService;

    @RequestMapping(value ="/",method=RequestMethod.GET)
    public @ResponseBody
    Object welcome() {
        def jiraStatus=new JiraStatus()
//        jiraStatus.key="1"
        jiraStatus.status="Welcome to JiraService"
        return jiraStatus
    }
    @RequestMapping(value ="",method=RequestMethod.GET)
    public @ResponseBody
    Object welcomeHome() {
        def jiraStatus=new JiraStatus()
//        jiraStatus.key="1"
        jiraStatus.status="Welcome to JiraService"
        return jiraStatus
    }



    @RequestMapping(value ="/search",method=RequestMethod.GET)
    public @ResponseBody
    Object getJiraIssue(@RequestParam(value="key", required=false, defaultValue="SYN-1") String key) {
        return jiraService.retriveIssue(key);
    }

    @RequestMapping(value ="/updatestatus",method=RequestMethod.POST)
    public @ResponseBody
    Object changeJiraStatus(@RequestBody jiraStatus) {
        return jiraService.updateStatus(jiraStatus.key,jiraStatus.status)
    }

    @RequestMapping(path = "/attachment", method = RequestMethod.GET)
    public ResponseEntity<Resource> getJiraIssueAttachment(
            @RequestParam(value="key", required=false, defaultValue="SYN-1") String key) throws IOException {
        byte[] bytes=jiraService.downloadIssue(key)
        InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(bytes));
        return ResponseEntity.ok()
//                .headers("Content-Disposition", "attachment;")
                .contentLength(bytes.length)
                .contentType(MediaType.parseMediaType("application/octet-stream"))
                .body(resource);
    }

}
