package com.hack.syncit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
@Configuration
@ComponentScan
@EnableAutoConfiguration
public class Application {
	private static final Logger LOG = LoggerFactory.getLogger(Application.class);

	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(Application.class);
		application.setHeadless(true);
		application.setRegisterShutdownHook(true);
		application.setLogStartupInfo(false);
		application.setWebEnvironment(true);
//		application.addListeners(new ApplicationPidFileWriter());
		application.run(args);

		LOG.info("Jiraservice Application launched [OK]");
	}
}
