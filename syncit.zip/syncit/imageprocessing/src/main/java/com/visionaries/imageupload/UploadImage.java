package com.visionaries.imageupload;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

public class UploadImage {

	public static void main(String... args) throws IOException {

		System.setProperty("GOOGLE_APPLICATION_CREDENTIALS", "src/main/resources/cred/service_account.json");
		
		Path path = Paths.get("src/main/resources/images/jira_image.jpg");
		byte[] data = Files.readAllBytes(path);
		System.out.println(path.toAbsolutePath());

		Storage storage = StorageOptions.newBuilder()
			    .setCredentials(ServiceAccountCredentials.fromStream(new FileInputStream("src/main/resources/cred/service_account.json")))
			    .build()
			    .getService();
		BlobId blobId = BlobId.of("amoghsbucket", "jira_image_syn.jpg");
		BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("image/jpeg").build();
		Blob blob = storage.create(blobInfo, data);
		System.out.println(blob.getBlobId());
	}
}