package com.visionaries;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.visionaries.email.SendEmail;
import com.visionaries.jiraclient.JiraIssue;
import com.visionaries.jiraclient.VisionJiraClient;
import com.visionaries.services.VisionService;

import autovalue.shaded.org.apache.commons.lang.BooleanUtils;
import autovalue.shaded.org.apache.commons.lang.StringUtils;

@SuppressWarnings("serial")
public class VisionServlet extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		PrintWriter out = resp.getWriter();

		String gsURL = req.getParameter("gsloc");
		if (gsURL == null) {
			out.println("Unable to process input file : " + gsURL);
			return;
		}

		String jiraKeyword = req.getParameter("jirakey");

		VisionService visionService = new VisionService();
		Map<String, String> jiraMap = visionService.getJiraIdentifiers(gsURL);

		List<JiraIssue> jiraIssueList = new ArrayList<JiraIssue>();

		addJirasToList(jiraMap.get("TO DO"), "To Do", jiraIssueList, jiraKeyword);
		addJirasToList(jiraMap.get("IN PROGRESS"), "In Progress", jiraIssueList, jiraKeyword);
		addJirasToList(jiraMap.get("BLOCKED"), "Blocked", jiraIssueList, jiraKeyword);
		addJirasToList(jiraMap.get("DONE"), "Done", jiraIssueList, jiraKeyword);

		out.println("<table>");
		out.println("<tr><td>JIRA_ID</td><td>JIRA STATUS</td><td>RESPONSE</td></tr>");

		String emailBody = "";
		
		VisionJiraClient jiraClient = new VisionJiraClient();
		for (JiraIssue jiraIssue : jiraIssueList) {
			Boolean isUpdated = jiraClient.updateJiraId(jiraIssue.getKey(), jiraIssue.getStatus());
			if (BooleanUtils.isFalse(isUpdated)) {
				jiraIssue.setDescription("FAILED");
			} else {
				jiraIssue.setDescription("SUCCESS");
			}
			emailBody = emailBody + jiraIssue.getKey()+","+jiraIssue.getStatus()+","+jiraIssue.getDescription()+"\n";
			out.println("<tr>" + "<td>" + jiraIssue.getKey() + "</td>" + "<td>" + jiraIssue.getStatus() + "</td>"
					+ "<td>" + jiraIssue.getDescription() + "</td>" + "</tr");
		}
		out.println("</table>");
		
		//byte[] data = emailBody.getBytes();
		System.out.println(emailBody);
		SendEmail mailSender = new SendEmail();
		mailSender.sendEmail(emailBody);
		

		/*Storage storage = StorageOptions.newBuilder()
			    .setCredentials(ServiceAccountCredentials.fromStream(VisionServlet.class.getResourceAsStream("/service_account.json")))
			    .build()
			    .getService();
		BlobId blobId = BlobId.of("amoghsbucket", "syncIt_status.txt");
		BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("text/plain").build();
		Blob blob = storage.create(blobInfo, data);
		System.out.println(blob.getBlobId());*/
				
	}

	private void addJirasToList(String concatenatedJiraString, String jiraStatus, List<JiraIssue> jiraIssueList,
			String jiraKeyword) {

		concatenatedJiraString = StringUtils.trim(concatenatedJiraString);

		if (concatenatedJiraString != null) {
			List<String> jiraList = Arrays.asList(concatenatedJiraString.split(" "));
			for (String jiraId : jiraList) {
				if (StringUtils.contains(jiraId, jiraKeyword)) {
					jiraIssueList.add(new JiraIssue(StringUtils.trim(jiraId), StringUtils.trim(jiraStatus)));
				}
			}
		}
	}
}
