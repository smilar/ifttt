package com.visionaries.jiraclient;

public class JiraIssue {
	
	private String key;
	private String status;
	private String description;
	
	public JiraIssue(String inKey, String inStatus){
		key = inKey;
		status = inStatus;
	}
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
