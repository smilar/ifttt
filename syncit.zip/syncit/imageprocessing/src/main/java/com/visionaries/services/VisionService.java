package com.visionaries.services;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

import autovalue.shaded.org.apache.commons.lang.StringUtils;

public class VisionService {

	private static final String API_URL = "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyD8nmz_2tlWigeoxtsd6jKaOM1OyimMS_w";
		
	public Map<String, String> getJiraIdentifiers(String gsUrl) throws IOException {
		
		String requestString = 
				"{"
				   +"\"requests\": ["
				   + "{"
				   +   "\"image\": {"
				   +     "\"source\": {"
				   +       "\"imageUri\": \"GSURL\""
				   +       "}"
				   +   "},"
				   +   "\"features\": ["
				   +     "{"
				   +       "\"type\": \"TEXT_DETECTION\""
				   +     "}"
				   +   "]"
				   + "}"
				  +"]"
				+"}";

		Map<String, String> visionMap = new HashMap<String, String>();

		
		requestString = StringUtils.replace(requestString, "GSURL", gsUrl);
		
		System.out.println(requestString);
		
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(API_URL);
		Response response = target.request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(requestString, MediaType.APPLICATION_JSON));

		String annotateResponse = response.readEntity(String.class);

		JSONObject obj = new JSONObject(annotateResponse);
		JSONObject resArray = obj.getJSONArray("responses").getJSONObject(0);
		JSONObject annotArray= resArray.optJSONArray("textAnnotations").getJSONObject(0);
		String responseString=annotArray.getString("description");
		
		String casedString = StringUtils.upperCase(StringUtils.replace(responseString, "\n", " "));
		System.out.println(casedString);
		String[] array1 = casedString.split("TO DO");
		String[] array2 = null;
		if (array1 != null && array1.length > 1){
			array2 = array1[1].split("IN PROGRESS");
		}
		String[] array3 = null;
		if (array2 != null && array2.length > 1){
			visionMap.put("TO DO", array2[0]);
			array3 = array2[1].split("BLOCKED");
		}
		String[] array4 = null;
		if (array3 != null && array3.length > 1){
			visionMap.put("IN PROGRESS", array3[0]);
			array4 = array3[1].split("DONE");
		}
		if (array4 != null && array4.length > 1){
			visionMap.put("BLOCKED", array4[0]);
			visionMap.put("DONE", array4[1]);
		}
		return visionMap;
	}
}