package com.visionaries.jiraclient;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

import autovalue.shaded.org.apache.commons.lang.StringUtils;

public class VisionJiraClient {

	private static final String JIRA_URL = "https://visionaries-syncit-jiraclient.appspot.com/jiraservice/";
	private static final String JIRA_PATH = "updatestatus";

	public Boolean updateJiraId(String jiraId, String updatedStatus) {
		Boolean isUpdateSuccess = false;

		String requestJson = "{" + "\"key\":\"JIRA_KEY\"," + "\"status\":\"JIRA_STATUS\"" + "}";

		Client client = ClientBuilder.newClient();

		requestJson = StringUtils.replace(requestJson, "JIRA_KEY", jiraId);
		requestJson = StringUtils.replace(requestJson, "JIRA_STATUS", updatedStatus);

		WebTarget target = client.target(JIRA_URL);
		Response response = target.path(JIRA_PATH).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(requestJson, MediaType.APPLICATION_JSON));
		if (response != null) {
			String issue = response.readEntity(String.class);
			JSONObject obj = new JSONObject(issue);
			try {
				String returnedUpdatedStatus = obj.getString("status");
				if (StringUtils.equals(returnedUpdatedStatus, "SUCCESS")) {
					isUpdateSuccess = true;
				}
			} catch (org.json.JSONException jsonException) {
				System.out.println(
						"Error occurred while updating jira id : " + jiraId + " with status : " + updatedStatus);
			}
		}
		return isUpdateSuccess;
	}
}
