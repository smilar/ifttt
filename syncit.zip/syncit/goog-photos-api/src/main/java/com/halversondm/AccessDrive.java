package com.halversondm;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.*;
import com.google.api.services.drive.model.File;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by halversondm on 6/21/17.
 */
@Component
public class AccessDrive {

    private static final Logger LOGGER = LogManager.getLogger(AccessDrive.class);
    private static final String APPLICATION_NAME = "visionaries-syncit";
    private static final String BUCKET = "amoghsbucket";
    private static final String BUCKET_FILE_NAME = "jira_image_syn.jpg";
    private static final String IMAGE_JPEG = "image/jpeg";
    private static final String GOOG_API_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssXXX";
    private HttpTransport httpTransport;
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    private Drive drive;
    private Storage storage;
    private String savedFileId = "";

    private Credential authorizeDrive() throws Exception {
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY,
                new InputStreamReader(App.class.getResourceAsStream("/client_id.json")));
        Details details = JSON_FACTORY.fromReader(new InputStreamReader(AccessDrive.class.getResourceAsStream("/oauth2playground.json")), Details.class);
        GoogleCredential credential = new GoogleCredential.Builder().setTransport(httpTransport).setJsonFactory(JSON_FACTORY).setClientSecrets(clientSecrets).build().setRefreshToken(details.getRefreshToken());
        return credential;
    }

    private ServiceAccountCredentials authorizeCloud() throws Exception {
        return ServiceAccountCredentials.fromStream(App.class.getResourceAsStream("/service_account.json"));
    }

    @Scheduled(fixedDelay = 10000)
    public void run() {
        try {
            String createdTime = getDateToSearchBy();
            boolean uploaded = findFiles(createdTime);
            if (uploaded) {
                callVisionUploadApi();
            }
        } catch (Exception e) {
            LOGGER.error("", e);
        }
    }

    private void callVisionUploadApi() throws Exception {
        URL url = new URL("http://visionaries-syncit.appspot.com/vision?gsloc=gs%3A%2F%2Famoghsbucket%2Fjira_image_syn.jpg&jirakey=SYN");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", "Mozilla/5.0");

        int responseCode = conn.getResponseCode();
        LOGGER.info("called vision service with response code {}", responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        //print result
        LOGGER.info("HTTP response {}", response.toString());
    }

    private boolean findFiles(String createdTime) throws IOException {
        FileList result = drive.files().list()
                .setQ("mimeType = 'image/jpeg' and createdTime >= '" + createdTime + "'")
                .setSpaces("photos")
                .setFields("files(id, name)")
                .execute();

        if (result.getFiles() != null && result.getFiles().size() > 0) {
            File file = result.getFiles().get(0);
            LOGGER.info("Found file {} {}", file.getName(), file.getId());
            if (!file.getId().equals(savedFileId)) {
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                drive.files().get(file.getId()).executeMediaAndDownloadTo(outputStream);
                BlobId blobId = BlobId.of(BUCKET, BUCKET_FILE_NAME);
                BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType(IMAGE_JPEG).build();
                Blob blob = storage.create(blobInfo, outputStream.toByteArray());
                LOGGER.info("Blob created in Storage with ID {}", blob.getBlobId());
                savedFileId = file.getId();
                return true;
            } else {
                return false;
            }
        } else {
            LOGGER.info("No files found in this run.");
            return false;
        }
    }

    private String getDateToSearchBy() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR, -1);
        Date newDate = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat(GOOG_API_DATE_FORMAT);
        String createdTime = sdf.format(newDate);
        LOGGER.info(createdTime);
        return createdTime;
    }

    @PostConstruct
    private void setup() throws Exception {
        httpTransport = GoogleNetHttpTransport.newTrustedTransport();
        // setup Cloud Storage instance
        ServiceAccountCredentials authorizeCloud = authorizeCloud();
        storage = StorageOptions.newBuilder()
                .setCredentials(authorizeCloud)
                .setProjectId(APPLICATION_NAME)
                .build()
                .getService();
        // set up the global Drive instance
        Credential authorizeDrive = authorizeDrive();
        drive = new Drive.Builder(httpTransport, JSON_FACTORY, authorizeDrive).setApplicationName(
                APPLICATION_NAME).build();
    }
}
